"""Board geometry shared by every script (mm, y up; x as seen from the REAR / component side).

V3.2: O48 ROUND board (full circle + the flat at the FPC) for a standard 52 mm DIN gauge body (bore O48.8).
  The whole V3.1 layout moved down by DY = 0.35 mm so the module's antenna end is inside the circle (V3.1 had a notch
  and the module stuck out above it). The antenna gets a copper keep-out (ANT_KEEPOUT, all layers) instead of a cut-out.
  REAR face (PCB TOP, towards the cap): ESP32-S3 module (antenna up at 12 o'clock), 40-pin FPC on the flat at 6 o'clock
      (flex wraps round the flat edge), the RGB bus between them on top copper, every connector: J_PWR1 / J_PWR2 (XH-4)
      + J_IO / J_SENS (2x3) in one 2x2 block on the right, USB-C, BOOT / RESET and the power LED on the left.
  FRONT face (PCB BOTTOM, towards the glass): all the other SMD circuitry (<= 3 mm tall).
"""
import math

R = 24.0                              # O48
DY = -0.35                            # V3.2 shift of the whole V3.1 layout (parts, tracks, vias, holes, flat)
ANT_KEEPOUT = (-12.0, 8.0, 15.3 + DY, R)   # antenna: no copper, no parts, all layers (x0, x1, y0, y1)
NOTCH_X0, NOTCH_X1, NOTCH_D = ANT_KEEPOUT[0], ANT_KEEPOUT[1], ANT_KEEPOUT[2]   # kept for older scripts (no cut-out)
FLAT_Y = -20.4 + DY                   # flat chord = FPC connector face (body front at -20.68)
MODULE_XY = (-2.0, 5.0 + DY)          # module pad-field centre, rot 180 (antenna +y)
JLCD_XY = (0.0, -16.8 + DY)           # FPC connector origin, rot 180 (opening towards the flat)
HOLES = [(-17.2, 14.0 + DY), (-17.2, -14.0 + DY), (19.1, 11.7 + DY)]   # 3x 2.2 NPTH, keyed (asymmetric)
# rear connectors: ref -> (x, y, rot); J_SENS turned so K_LINE / ILLUM_IN (pins 5/6) face their protection parts
HEADERS = {'J_PWR1': (13.05, 6.5 + DY, 90), 'J_PWR2': (13.05, -6.5 + DY, 90), 'J_IO': (19.35, 4.2 + DY, 90), 'J_SENS': (19.35, -4.2 + DY, 270)}
USB_POSE = (-17.2, 0.0 + DY, 90)


def header_pose(ref):
    if ref == 'USB_ESP':
        return USB_POSE
    return HEADERS.get(ref)


# V3.3: the user cut the antenna notch back into their outline (x -11.1 .. 7.11, open above y 15.03).
NOTCH = (-11.1, 7.11, 15.03)


def outline_pts(n=360):
    """Closed polygon, counter-clockwise, starting at the flat's right end: arc up to the notch, notch, arc down, flat."""
    xf = math.sqrt(R * R - FLAT_Y * FLAT_Y)
    a0 = math.degrees(math.atan2(FLAT_Y, xf))
    nx0, nx1, ny = NOTCH
    aR = math.degrees(math.acos(nx1 / R)); aL = math.degrees(math.acos(nx0 / R))
    k1 = max(4, int((aR - a0) / 360 * n)); k2 = max(4, int((180.0 - a0 - aL) / 360 * n))
    pts = [(R * math.cos(math.radians(a0 + (aR - a0) * i / k1)), R * math.sin(math.radians(a0 + (aR - a0) * i / k1))) for i in range(k1 + 1)]
    pts += [(nx1, ny), (nx0, ny)]
    a2 = 180.0 - a0
    pts += [(R * math.cos(math.radians(aL + (a2 - aL) * i / k2)), R * math.sin(math.radians(aL + (a2 - aL) * i / k2))) for i in range(k2 + 1)]
    pts[0] = (xf, FLAT_Y); pts[-1] = (-xf, FLAT_Y)
    return pts


def outline_pts_round(n=360):
    """V3.2 round outline (no notch) - kept for the housing, which is the same either way."""
    xf = math.sqrt(R * R - FLAT_Y * FLAT_Y)
    a0 = math.degrees(math.atan2(FLAT_Y, xf))                        # ~ -60
    a1 = 180.0 - a0                                                   # ~ 240
    k = int((a1 - a0) / 360 * n)
    pts = [(R * math.cos(math.radians(a0 + (a1 - a0) * i / k)), R * math.sin(math.radians(a0 + (a1 - a0) * i / k))) for i in range(k + 1)]
    pts[0] = (xf, FLAT_Y); pts[-1] = (-xf, FLAT_Y)
    return pts


def in_notch(x, y, tol=0.0):
    nx0, nx1, ny = NOTCH
    return nx0 - tol < x < nx1 + tol and y > ny - tol


def inside(x, y, margin=0.0):
    if math.hypot(x, y) > R - margin:
        return False
    if y < FLAT_Y + margin:
        return False
    if in_notch(x, y, margin):
        return False
    return True


def rect_ok(x0, y0, x1, y1, margin=0.0):
    n = 6
    for i in range(n + 1):
        for cx, cy in ((x0 + (x1 - x0) * i / n, y0), (x0 + (x1 - x0) * i / n, y1), (x0, y0 + (y1 - y0) * i / n), (x1, y0 + (y1 - y0) * i / n)):
            if not inside(cx, cy, margin):
                return False
    return True


if __name__ == '__main__':
    p = outline_pts()
    xs = [a for a, b in p]; ys = [b for a, b in p]
    print(len(p), 'x %.2f..%.2f  y %.2f..%.2f' % (min(xs), max(xs), min(ys), max(ys)))
    area = 0.5 * abs(sum(p[i][0] * p[(i + 1) % len(p)][1] - p[(i + 1) % len(p)][0] * p[i][1] for i in range(len(p))))
    print('area %.0f mm2 (full O48 disc %.0f); flat half-width %.2f' % (area, math.pi * R * R, math.sqrt(R * R - FLAT_Y ** 2)))
    print('holes r', [round(math.hypot(*h), 2) for h in HOLES])
