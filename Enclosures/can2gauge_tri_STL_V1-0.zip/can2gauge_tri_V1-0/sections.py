"""Section drawings of the triple holder, straight from the SDFs (world frame, mm)."""
import sys, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import os, struct
import pod10 as p, frame as F, triple as T

def load_stl(path):
    d = open(path, 'rb').read(); n = struct.unpack('<I', d[80:84])[0]
    a = np.frombuffer(d[84:84 + 50 * n], dtype=np.dtype([('n', '<3f4'), ('v', '<9f4'), ('a', '<u2')]))
    return a['v'].reshape(-1, 3, 3).astype(float)

def section(t, axis, val):
    dd = t[:, :, axis] - val; segs = []
    for tri, d in zip(t, dd):
        pts = [tri[i] + d[i] / (d[i] - d[(i + 1) % 3]) * (tri[(i + 1) % 3] - tri[i]) for i in range(3) if (d[i] < 0) != (d[(i + 1) % 3] < 0)]
        if len(pts) == 2: segs.append(pts)
    return np.array(segs)

TRIAL_STL = os.environ.get('TRIAL_STL', 'DIN_Gauge_Holder_Trial.STL')     # the trial holder, for the red outline
TRIAL = load_stl(TRIAL_STL) if os.path.exists(TRIAL_STL) else None
COL = {'pod': '#8fa6c2', 'base': '#d2a86e', 'bezel': '#3a3a44', 'cap': '#6fae7f', 'pcb': '#2f7d4f', 'panel': '#b9d8f0'}

def gauge_sdf(fn, X, Y, Z):
    s = np.full(X.shape, 1e3)
    for O in T.CENTRES:
        x, y, z = T.pod_frame(X, Y, Z, O)
        m = (np.abs(x) < 40) & (np.abs(y) < 40) & (z > -2) & (z < p.CAP_Z1 + 2)
        if m.any():
            s[m] = np.minimum(s[m], fn(x[m], y[m], z[m]))
    return s

def parts(X, Y, Z):
    return {'base': T.sdf_base(X, Y, Z), 'pod': T.sdf_pod(X, Y, Z), 'bezel': T.sdf_bezel(X, Y, Z),
            'cap': gauge_sdf(p.sdf_cap, X, Y, Z), 'pcb': gauge_sdf(p.sdf_pcb, X, Y, Z), 'panel': gauge_sdf(p.sdf_glass, X, Y, Z)}

def draw(ax, H, V, S, title, trial_axis=None, trial_val=None, hv=(0, 1)):
    for k in ('base', 'pod', 'cap', 'pcb', 'panel', 'bezel'):
        ax.contourf(H, V, S[k], levels=[-1e3, 0], colors=[COL[k]])
        ax.contour(H, V, S[k], levels=[0], colors='k', linewidths=0.3)
    if trial_axis is not None and TRIAL is not None:
        seg = section(TRIAL, trial_axis, trial_val)
        for a, b in seg:
            ax.plot([a[hv[0]], b[hv[0]]], [a[hv[1]], b[hv[1]]], color='#d33', lw=0.8)
    ax.set_aspect('equal'); ax.grid(alpha=0.25); ax.set_title(title, fontsize=10)

def vertical(x0, ax, res=0.12):
    zs = np.arange(-2, 84, res); ys = np.arange(-10, 80, res)
    Zg, Yg = np.meshgrid(zs, ys)
    S = parts(np.full(Zg.shape, x0), Yg, Zg)
    draw(ax, Zg, Yg, S, 'section X = %.1f' % x0, 0, x0, hv=(2, 1))
    ax.axvline(F.DASH_Z, color='#d33', ls='--', lw=0.8); ax.text(F.DASH_Z - 1, -8, 'dash', color='#d33', ha='right', fontsize=8)
    ax.set_xlabel('Z (out of the dash)'); ax.set_ylabel('Y (up)')

def plan(y0, ax, res=0.15):
    xs = np.arange(-22, 214, res); zs = np.arange(-2, 84, res)
    Xg, Zg = np.meshgrid(xs, zs)
    S = parts(Xg, np.full(Xg.shape, y0), Zg)
    draw(ax, Xg, Zg, S, 'plan section Y = %.1f (gauge centres)' % y0, 1, y0, hv=(0, 2))
    ax.axhline(F.DASH_Z, color='#d33', ls='--', lw=0.8)
    ax.set_xlabel('X (driver side ->)'); ax.set_ylabel('Z')

if __name__ == '__main__':
    out = sys.argv[1] if len(sys.argv) > 1 else 'out'
    fig = plt.figure(figsize=(18, 13))
    gs = fig.add_gridspec(2, 3, height_ratios=[1, 1.05])
    vertical(float(T.CENTRES[1][0]), fig.add_subplot(gs[0, 0]))
    vertical(float(T.CENTRES[2][0]), fig.add_subplot(gs[0, 1]))
    vertical(186.0, fig.add_subplot(gs[0, 2]))
    plan(float(T.CENTRES[1][1]), fig.add_subplot(gs[1, :]))
    fig.legend(handles=[Patch(color=COL[k], label=k) for k in COL] + [Patch(color='#d33', label='trial holder (outline)')],
               loc='upper center', ncol=7, fontsize=10)
    plt.tight_layout(rect=(0, 0, 1, 0.96))
    plt.savefig(out + '/can2gauge_tri_V1-0_sections.png', dpi=80)
