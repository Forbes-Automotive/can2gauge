"""World frame = the trial holder's frame (SolidWorks export): X across the car (+X = driver side for RHD), Y up,
Z out of the dash towards the cabin. DIN box X 4..184, Y 1.6..56.6, Z 0..28; dash contact plane Z = 28."""
import numpy as np
D = np.array([0.076372, 0.173141, 0.981931]); D /= np.linalg.norm(D)   # trial cup axis / rim-plane normal (10.0 deg up, 4.45 deg to +X)
U = np.cross([0.0, 1.0, 0.0], D); U /= np.linalg.norm(U)                # panel x (right, seen from the front)
W = np.cross(D, U)                                                      # panel y (up = antenna end; neck at -W)
BOX_O = (4.0, 184.0, 1.6, 56.6)        # DIN box outside, from the trial
BOX_WALL = 2.4
BOX_I = (BOX_O[0] + BOX_WALL, BOX_O[1] - BOX_WALL, BOX_O[2] + BOX_WALL, BOX_O[3] - BOX_WALL)
DASH_Z = 28.0                          # trial flange back face = dash surface round the DIN opening
BOX_Z0 = 0.0
AXIS_XY = (92.1, 24.8)                 # middle gauge axis at the dash plane: puts the pod footprint central on the DIN box
PITCH = 74.0                           # lens recess O71.87 + 2.13 web
def origin(s):
    return np.array([AXIS_XY[0], AXIS_XY[1], DASH_Z]) + s * D
def to_local(P, O):
    """world (...,3) -> panel model frame M: x right, y up, z backwards from the lens front"""
    Q = P - O
    return Q @ U, Q @ W, -(Q @ D)
def to_world(x, y, z, O):
    return O + np.multiply.outer(x, U) + np.multiply.outer(y, W) - np.multiply.outer(z, D)
