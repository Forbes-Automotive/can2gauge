// Quadric edge-collapse simplifier for closed STL meshes (Garland-Heckbert, threshold-limited "lossless" mode).
// usage: qem in.stl out.stl max_err [max_iter]
//   max_err: largest quadric error (squared distance, mm^2) a collapse may introduce.
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cstdint>
#include <array>
struct K { uint32_t a, b, c; bool operator==(const K& o) const { return a == o.a && b == o.b && c == o.c; } };
struct KH { size_t operator()(const K& k) const { uint64_t h = k.a * 0x9E3779B97F4A7C15ULL; h ^= (k.b + 0x632BE59BD9B4E019ULL + (h << 6) + (h >> 2)); h ^= (k.c * 0x94D049BB133111EBULL) + (h << 6) + (h >> 2); return h; } };
using namespace std;
struct V3 { double x, y, z; };
static inline V3 operator+(V3 a, V3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
static inline V3 operator-(V3 a, V3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static inline V3 operator*(V3 a, double s) { return {a.x * s, a.y * s, a.z * s}; }
static inline double dot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline V3 cross(V3 a, V3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
static inline double len(V3 a) { return sqrt(dot(a, a)); }
static inline V3 nrm(V3 a) { double l = len(a); return l > 0 ? a * (1.0 / l) : a; }
struct Q { double m[10]; Q() { memset(m, 0, sizeof m); }
  Q(double a, double b, double c, double d) { m[0]=a*a; m[1]=a*b; m[2]=a*c; m[3]=a*d; m[4]=b*b; m[5]=b*c; m[6]=b*d; m[7]=c*c; m[8]=c*d; m[9]=d*d; }
  Q operator+(const Q& o) const { Q r; for (int i = 0; i < 10; i++) r.m[i] = m[i] + o.m[i]; return r; }
  double err(V3 p) const { double x=p.x,y=p.y,z=p.z; return m[0]*x*x + 2*m[1]*x*y + 2*m[2]*x*z + 2*m[3]*x + m[4]*y*y + 2*m[5]*y*z + 2*m[6]*y + m[7]*z*z + 2*m[8]*z + m[9]; }
};
struct Tri { int v[3]; double e[4]; bool del, dirty; V3 n; };
struct Vert { V3 p; Q q; int ts, tc; };
struct Ref { int t, tv; };
vector<Tri> T; vector<Vert> Vx; vector<Ref> R;

static double det3(double a,double b,double c,double d,double e,double f,double g,double h,double i){ return a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g); }
double cerr(int i0, int i1, V3& out) {
  Q q = Vx[i0].q + Vx[i1].q; const double* m = q.m;
  double D = det3(m[0],m[1],m[2], m[1],m[4],m[5], m[2],m[5],m[7]);
  if (fabs(D) > 1e-10) {
    double b0 = -m[3], b1 = -m[6], b2 = -m[8];
    V3 p = { det3(b0,m[1],m[2], b1,m[4],m[5], b2,m[5],m[7]) / D,
             det3(m[0],b0,m[2], m[1],b1,m[5], m[2],b2,m[7]) / D,
             det3(m[0],m[1],b0, m[1],m[4],b1, m[2],m[5],b2) / D };
    // keep the optimum near the edge (ill-conditioned quadrics can throw it far away)
    V3 a = Vx[i0].p, b = Vx[i1].p, mid = (a + b) * 0.5;
    if (len(p - mid) < 2.0 * len(b - a) + 1e-9) { out = p; return q.err(p); }
  }
  V3 a = Vx[i0].p, b = Vx[i1].p, c = (a + b) * 0.5;
  double ea = q.err(a), eb = q.err(b), ec = q.err(c);
  double e = min(ea, min(eb, ec));
  out = (e == ea) ? a : (e == eb ? b : c);
  return e;
}
bool flipped(V3 p, int i0, int i1, Vert& v0, vector<int>& dl) {
  for (int k = 0; k < v0.tc; k++) {
    Tri& t = T[R[v0.ts + k].t]; if (t.del) continue;
    int s = R[v0.ts + k].tv, id1 = t.v[(s + 1) % 3], id2 = t.v[(s + 2) % 3];
    if (id1 == i1 || id2 == i1) { dl[k] = 1; continue; }
    V3 d1 = nrm(Vx[id1].p - p), d2 = nrm(Vx[id2].p - p);
    if (fabs(dot(d1, d2)) > 0.999) return true;
    V3 n = nrm(cross(d1, d2)); dl[k] = 0;
    if (dot(n, t.n) < 0.2) return true;
  }
  return false;
}
// link condition: the two vertices may share exactly two neighbours (closed manifold), otherwise the collapse pinches
bool link_ok(int i0, int i1) {
  static vector<int> mark; if ((int)mark.size() < (int)Vx.size()) mark.assign(Vx.size(), -1);
  static int stamp = 0; stamp++;
  Vert& a = Vx[i0]; Vert& b = Vx[i1];
  for (int k = 0; k < a.tc; k++) { Tri& t = T[R[a.ts + k].t]; if (t.del) continue; for (int j = 0; j < 3; j++) mark[t.v[j]] = stamp; }
  vector<int> shared;
  for (int k = 0; k < b.tc; k++) { Tri& t = T[R[b.ts + k].t]; if (t.del) continue;
    for (int j = 0; j < 3; j++) { int w = t.v[j]; if (w != i0 && w != i1 && mark[w] == stamp) { if (find(shared.begin(), shared.end(), w) == shared.end()) shared.push_back(w); } } }
  return shared.size() == 2;
}
void upd(int i0, Vert& v, vector<int>& dl, int& ndel) {
  V3 p;
  for (int k = 0; k < v.tc; k++) {
    Ref r = R[v.ts + k]; Tri& t = T[r.t]; if (t.del) continue;
    if (dl[k]) { t.del = 1; ndel++; continue; }
    t.v[r.tv] = i0; t.dirty = 1;
    t.e[0] = cerr(t.v[0], t.v[1], p); t.e[1] = cerr(t.v[1], t.v[2], p); t.e[2] = cerr(t.v[2], t.v[0], p);
    t.e[3] = min(t.e[0], min(t.e[1], t.e[2]));
    R.push_back(r);
  }
}
void update_mesh(int it) {
  if (it > 0) { int dst = 0; for (size_t i = 0; i < T.size(); i++) if (!T[i].del) T[dst++] = T[i]; T.resize(dst); }
  for (auto& v : Vx) { v.ts = 0; v.tc = 0; }
  for (auto& t : T) for (int j = 0; j < 3; j++) Vx[t.v[j]].tc++;
  int ts = 0; for (auto& v : Vx) { v.ts = ts; ts += v.tc; v.tc = 0; }
  R.resize(T.size() * 3);
  for (size_t i = 0; i < T.size(); i++) for (int j = 0; j < 3; j++) { Vert& v = Vx[T[i].v[j]]; R[v.ts + v.tc] = {(int)i, j}; v.tc++; }
  if (it == 0) {
    for (auto& t : T) { V3 p0 = Vx[t.v[0]].p; V3 n = nrm(cross(Vx[t.v[1]].p - p0, Vx[t.v[2]].p - p0)); t.n = n;
      Q q(n.x, n.y, n.z, -dot(n, p0)); for (int j = 0; j < 3; j++) Vx[t.v[j]].q = Vx[t.v[j]].q + q; }
    V3 p; for (auto& t : T) { for (int j = 0; j < 3; j++) t.e[j] = cerr(t.v[j], t.v[(j + 1) % 3], p); t.e[3] = min(t.e[0], min(t.e[1], t.e[2])); }
  } else {
    for (auto& t : T) { V3 p0 = Vx[t.v[0]].p; t.n = nrm(cross(Vx[t.v[1]].p - p0, Vx[t.v[2]].p - p0)); }
  }
}
int main(int argc, char** argv) {
  if (argc < 4) { fprintf(stderr, "usage: qem in.stl out.stl max_err [max_iter]\n"); return 1; }
  double maxe = atof(argv[3]); int maxit = argc > 4 ? atoi(argv[4]) : 200;
  FILE* f = fopen(argv[1], "rb"); char hdr[80]; fread(hdr, 1, 80, f); uint32_t n; fread(&n, 4, 1, f);
  unordered_map<K, int, KH> idx; idx.reserve(n * 2);
  T.reserve(n);
  for (uint32_t i = 0; i < n; i++) {
    float buf[12]; uint16_t a; fread(buf, 4, 12, f); fread(&a, 2, 1, f);
    Tri t; t.del = 0; t.dirty = 0;
    for (int j = 0; j < 3; j++) {
      float* p = buf + 3 + 3 * j; K k; memcpy(&k.a, p, 4); memcpy(&k.b, p + 1, 4); memcpy(&k.c, p + 2, 4);
      auto it = idx.find(k); int id;
      if (it == idx.end()) { id = Vx.size(); idx[k] = id; Vert v; v.p = {p[0], p[1], p[2]}; Vx.push_back(v); }
      else id = it->second;
      t.v[j] = id;
    }
    if (t.v[0] != t.v[1] && t.v[1] != t.v[2] && t.v[0] != t.v[2]) T.push_back(t);
  }
  fclose(f);
  fprintf(stderr, "in: %zu tris, %zu verts\n", T.size(), Vx.size());
  int ndel = 0; vector<int> dl0, dl1;
  for (int it = 0; it < maxit; it++) {
    if (it % 5 == 0) update_mesh(it);
    for (auto& t : T) t.dirty = 0;
    double th = 1e-9 * pow(double(it + 3), 7.0); bool capped = th >= maxe; if (capped) th = maxe;
    int before = ndel;
    for (size_t ti = 0; ti < T.size(); ti++) {
      Tri& t = T[ti];
      if (t.e[3] > th || t.del || t.dirty) continue;
      for (int j = 0; j < 3; j++) if (t.e[j] < th) {
        int i0 = t.v[j], i1 = t.v[(j + 1) % 3]; Vert& v0 = Vx[i0]; Vert& v1 = Vx[i1];
        V3 p; cerr(i0, i1, p);
        dl0.assign(v0.tc, 0); dl1.assign(v1.tc, 0);
        if (flipped(p, i0, i1, v0, dl0) || flipped(p, i1, i0, v1, dl1)) continue;
        if (!link_ok(i0, i1)) continue;
        v0.p = p; v0.q = v1.q + v0.q;
        int ts = R.size();
        upd(i0, v0, dl0, ndel); upd(i0, v1, dl1, ndel);
        int tc = R.size() - ts;
        if (tc <= v0.tc) { if (tc) memmove(&R[v0.ts], &R[ts], tc * sizeof(Ref)); }
        else v0.ts = ts;
        v0.tc = tc;
        break;
      }
    }
    if (it % 5 == 4 || capped) fprintf(stderr, "iter %d th %.2e removed %d (total %d)\n", it, th, ndel - before, ndel);
    if (capped && ndel - before < 50 && it % 5 == 4) break;
  }
  update_mesh(1);
  // compact vertices
  vector<int> remap(Vx.size(), -1); int nv = 0;
  for (auto& t : T) for (int j = 0; j < 3; j++) if (remap[t.v[j]] < 0) remap[t.v[j]] = nv++;
  FILE* o = fopen(argv[2], "wb"); memset(hdr, 0, 80); strcpy(hdr, "qem simplified"); fwrite(hdr, 1, 80, o);
  uint32_t m = T.size(); fwrite(&m, 4, 1, o);
  for (auto& t : T) {
    V3 a = Vx[t.v[0]].p, b = Vx[t.v[1]].p, c = Vx[t.v[2]].p; V3 nn = nrm(cross(b - a, c - a));
    float buf[12] = {(float)nn.x, (float)nn.y, (float)nn.z, (float)a.x, (float)a.y, (float)a.z, (float)b.x, (float)b.y, (float)b.z, (float)c.x, (float)c.y, (float)c.z};
    uint16_t at = 0; fwrite(buf, 4, 12, o); fwrite(&at, 2, 1, o);
  }
  fclose(o);
  fprintf(stderr, "out: %u tris, %d verts\n", m, nv);
  return 0;
}
