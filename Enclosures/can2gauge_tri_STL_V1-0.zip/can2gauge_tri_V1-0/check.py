"""Interference checks for the triple holder (SDF sampling, no meshes needed).
Every part of each gauge (cap, PCB, panel, plugs + wire room) against the pod, the base and the dash; base and bezel
against the pod."""
import numpy as np, pod10 as p, frame as F, cap4, triple as T

RES = 0.3
def solid_pts_local(fn, xr, yr, zr, res=RES):
    xs = np.arange(xr[0], xr[1], res); ys = np.arange(yr[0], yr[1], res); zs = np.arange(zr[0], zr[1], res)
    X, Y, Z = np.meshgrid(xs, ys, zs, indexing='ij')
    s = fn(X, Y, Z); m = s < -0.05                     # strictly inside (skip the skin)
    return X[m], Y[m], Z[m]

def report(name, d, tol=0.0):
    bad = d < -tol
    print('%-34s min clearance %6.2f mm  %s' % (name, d.min(), 'OK' if not bad.any() else 'CLASH (%d pts)' % bad.sum()))
    return bad

R = p.HEAD_R
def plugs_sdf(X, Y, Z):
    """plug bodies (PCB rear to window top) and the wire room behind the cap windows"""
    s = np.full(X.shape, 1e3)
    for ref, (x0, x1, y0, y1) in cap4.WINDOWS.items():
        s = np.minimum(s, p.box(X, Y, Z, x0, x1, y0, y1, p.Z_PCB_B, p.CAP_Z1 + T.WIRE))
    return s
def wire_sdf(X, Y, Z):
    s = np.full(X.shape, 1e3)
    for ref, (x0, x1, y0, y1) in cap4.WINDOWS.items():
        s = np.minimum(s, p.box(X, Y, Z, x0, x1, y0, y1, p.CAP_Z1 + 0.05, p.CAP_Z1 + T.WIRE))
    return s

worst = {}
for i, O in enumerate(T.CENTRES):
    tag = ['left', 'middle', 'right'][i]
    for name, fn, rng in [('cap', p.sdf_cap, ((-25, 25), (-25, 25), (p.Z_PCB_B - 0.5, p.CAP_Z1 + 0.5))),
                          ('pcb', p.sdf_pcb, ((-25, 25), (-25, 25), (p.Z_PCB_F - 0.2, p.Z_PCB_B + 0.2))),
                          ('panel', p.sdf_glass, ((-37, 37), (-37, 37), (-0.1, 4.0)))]:
        x, y, z = solid_pts_local(fn, *rng)
        P = F.to_world(x, y, z, O)
        dp = T.sdf_pod(P[:, 0], P[:, 1], P[:, 2])
        report('%s %s vs pod' % (tag, name), dp, tol=0.05)
        db = T.sdf_base(P[:, 0], P[:, 1], P[:, 2])
        report('%s %s vs base' % (tag, name), db, tol=0.0)
        if name == 'cap':
            outside = ~((P[:, 0] > F.BOX_O[0]) & (P[:, 0] < F.BOX_O[1]) & (P[:, 1] > F.BOX_O[2]) & (P[:, 1] < F.BOX_O[3]))
            report('%s cap vs dash (outside box)' % tag, P[outside, 2] - F.DASH_Z if outside.any() else np.array([9.9]))
    x, y, z = solid_pts_local(wire_sdf, (-25, 25), (-25, 25), (p.CAP_Z1, p.CAP_Z1 + T.WIRE + 0.5))
    P = F.to_world(x, y, z, O)
    report('%s wire room vs pod' % tag, T.sdf_pod(P[:, 0], P[:, 1], P[:, 2]))
    report('%s wire room vs base' % tag, T.sdf_base(P[:, 0], P[:, 1], P[:, 2]))
    outside = ~((P[:, 0] > T.BOX_I[0]) & (P[:, 0] < T.BOX_I[1]) & (P[:, 1] > T.BOX_I[2]) & (P[:, 1] < T.BOX_I[3]))
    report('%s wire room vs dash (outside box)' % tag, P[outside, 2] - F.DASH_Z if outside.any() else np.array([9.9]))

# base solid vs pod (they only touch on the rim plane)
lo, hi = T.extents()
xs = np.arange(lo[0] - 2, hi[0] + 2, 0.5); ys = np.arange(lo[1] - 2, hi[1] + 2, 0.5); zs = np.arange(0.2, T.RIM_Z - 0.05, 0.5)
X, Y, Z = np.meshgrid(xs, ys, zs, indexing='ij')
sb = T.sdf_base(X, Y, Z); m = sb < -0.05
report('base vs pod', T.sdf_pod(X[m], Y[m], Z[m]))
# pod below the rim plane (only the gauge tubes may dip into the deck openings)
zs = np.arange(T.RIM_Z - 4, T.RIM_Z - 0.05, 0.25)
X, Y, Z = np.meshgrid(xs, ys, zs, indexing='ij'); sp = T.sdf_pod(X, Y, Z); m = sp < -0.05
if m.any():
    report('pod below rim vs base', T.sdf_base(X[m], Y[m], Z[m]))
    report('pod below rim vs dash', Z[m] - F.DASH_Z - 0.5)
# bezel vs pod
a = np.arange(-T.L_ST - R - 2, T.L_ST + R + 2, 0.3); b = np.arange(-R - 2, R + 2, 0.3); c = np.arange(-1.6, 4.2, 0.2)
A, B, C = np.meshgrid(a, b, c, indexing='ij')
P = F.to_world(A.ravel(), B.ravel(), C.ravel(), T.O_MID)
sz = T.sdf_bezel(P[:, 0], P[:, 1], P[:, 2]); m = sz < -0.05
report('bezel vs pod', T.sdf_pod(P[m, 0], P[m, 1], P[m, 2]), tol=0.11)      # 0.1 bead clamps the lens, not the pod
# panels vs bezel: the bead should press each lens by ~0.1
for i, O in enumerate(T.CENTRES):
    x, y, z = solid_pts_local(p.sdf_glass, (-37, 37), (-37, 37), (-0.1, 1.0))
    P = F.to_world(x, y, z, O)
    report('%s lens vs bezel (bead press)' % ['left', 'middle', 'right'][i], T.sdf_bezel(P[:, 0], P[:, 1], P[:, 2]), tol=0.15)
