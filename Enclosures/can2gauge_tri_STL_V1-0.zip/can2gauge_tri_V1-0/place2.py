import numpy as np, pod10 as p, frame as F, cap4
WIRE = 4.0; CLR = 1.0
ROT = {-1: 0, 0: 0, 1: 0}          # all three panels neck-down (same assembly, no firmware flip)
def inside(P, R): return (P[:,0] > R[0]) & (P[:,0] < R[1]) & (P[:,1] > R[2]) & (P[:,1] < R[3])
def rot(x, y, deg):
    a = np.radians(deg); return x*np.cos(a) - y*np.sin(a), x*np.sin(a) + y*np.cos(a)
def check(s):
    O = F.origin(s); res = []
    th = np.linspace(0, 2*np.pi, 361)
    for i in (-1, 0, 1):
        Oi = O + i*F.PITCH*F.U
        # tube + cap: anything outside the DIN box outline must clear the dash
        for z in np.linspace(p.HEAD_Z1, p.CAP_Z1, 10):
            for r in np.linspace(0, p.BODY_R, 6):
                P = F.to_world(r*np.cos(th), r*np.sin(th), np.full_like(th, z), Oi)
                o = ~inside(P, F.BOX_O)
                if o.any(): res.append(((P[o,2] - F.DASH_Z - CLR).min(), ('tube', i, round(z,1))))
        # plug windows + wiring behind them: inside the box's inner opening or clear of the dash
        for ref, (x0, x1, y0, y1) in cap4.WINDOWS.items():
            X, Y = np.meshgrid(np.linspace(x0, x1, 8), np.linspace(y0, y1, 8)); X, Y = rot(X.ravel(), Y.ravel(), ROT[i])
            for z in np.linspace(p.CAP_Z1, p.CAP_Z1 + WIRE, 5):
                P = F.to_world(X, Y, np.full_like(X, z), Oi); o = ~inside(P, F.BOX_I)
                if o.any(): res.append(((P[o,2] - F.DASH_Z - CLR).min(), ('plug', i, ref)))
    a = np.linspace(-F.PITCH - p.HEAD_R, F.PITCH + p.HEAD_R, 400); b = np.linspace(-p.HEAD_R, p.HEAD_R, 120)
    A, B = np.meshgrid(a, b); st = np.maximum(np.abs(A) - F.PITCH, 0)**2 + B**2 <= p.HEAD_R**2
    P = F.to_world(A[st], B[st], np.full(st.sum(), p.HEAD_Z1), O); o = ~inside(P, F.BOX_O)
    res.append(((P[o,2] - F.DASH_Z - CLR).min(), ('plate',)))
    return min(res, key=lambda t: t[0])
if __name__ == '__main__':
    lo, hi = -30.0, 80.0
    for _ in range(50):
        mid = (lo+hi)/2
        if check(mid)[0] >= 0: hi = mid
        else: lo = mid
    s = hi; print('s', round(s,3), check(s)); O = F.origin(s)
    a = np.linspace(-F.PITCH - p.BEZEL_R, F.PITCH + p.BEZEL_R, 300); b = np.linspace(-p.BEZEL_R, p.BEZEL_R, 80)
    A, B = np.meshgrid(a, b); st = np.maximum(np.abs(A) - F.PITCH, 0)**2 + B**2 <= p.BEZEL_R**2
    P = F.to_world(A[st], B[st], np.full(st.sum(), -1.5), O)
    print('bezel front proud of dash', (P[:,2].min()-28).round(1), '..', (P[:,2].max()-28).round(1))
    for i in (-1,0,1):
        Oi = O + i*F.PITCH*F.U; print('gauge', i, 'lens centre', Oi.round(2), 'cap-rear centre', F.to_world(0,0,p.CAP_Z1,Oi).round(2))
