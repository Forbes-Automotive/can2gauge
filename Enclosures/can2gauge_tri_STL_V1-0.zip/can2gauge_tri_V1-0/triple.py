"""can2gauge Mk4 triple holder TRI V1.0 - three can2gauges (Saef SFTO210XC-7478A-CT touch panel, rev15 / V3.4 board)
built into one angled pod on the trial holder's DIN box.

World frame = the trial holder's own frame (DIN_Gauge_Holder_Trial.STL): X across the car (+X driver side, RHD),
Y up, Z out of the dash. DIN box X 4..184, Y 1.6..56.6, Z 0..28; the dash surface round the opening is Z = 28.
All three panels share the trial's rim plane angle: 10.0 deg up, 4.45 deg towards the driver.

Two printed parts plus the bezel and three standard CT V4.2 caps:
  pod   - the three heads merged into one stadium-shaped face plate (every head feature from pod10.py: lens recess,
          film/LCM pocket, neck pocket, flex cavity, M2 insert bosses), the three O51.8 tubes the caps fit into, and a
          hollow shroud swept straight back (along -Z) to the rim plane Z = RIM_Z. Prints face-down.
  base  - deck plate on the dash (Z 28 .. RIM_Z, same footprint as the shroud) with the trial's DIN box under it.
          The pod screws onto it with 6x M3 from the back (heat-set M3x4 inserts in the pod's rim bosses).
  bezel - one snap-on full-face bezel for all three lenses (O68 windows, 1.6 lip, 0.1 bead), seven hooks.
"""
import os, sys, math, numpy as np
from skimage import measure
import pod10 as p
import frame as F

p.SNAP_ANGLES = ()                     # the per-head bezel snap pockets don't apply: one shared bezel, its own pockets
RES = float(os.environ.get("ENC_RES", "0.25"))
S_PLACE = 36.23                        # place2.py: pod pushed out along the axis until the right gauge's plugs + 4 mm of
                                       # wire room clear the dash by 1 mm (binding point: right gauge J_BUS1)
O_MID = F.origin(S_PLACE)
CENTRES = [O_MID + i * F.PITCH * F.U for i in (-1, 0, 1)]
R_ST = p.HEAD_R                        # stadium half-height = head radius 38.0 (lens recess + 1.2, flex corners + 0.8)
L_ST = F.PITCH                         # stadium core half-length (outer gauge centres)
SKIN = 3.0                             # face-plate skin between the heads (hollowed from the back)
WALL = 2.4                             # shroud wall
RIM_Z = 32.0                           # pod rim / deck top
DECK_Z0 = F.DASH_Z                     # deck back face on the dash
ZD = F.D[2]; ZU = F.U[2]; ZW = F.W[2]  # world z components of the pod axes
WIRE = 4.0
# rim bosses for the pod-to-base screws, given in the pod frame at the plate rear (a, b); columns run along world Z
BOSS_AB = [(-(L_ST + 34.0), 0.0), (L_ST + 34.0, 0.0), (-37.0, 34.0), (37.0, 34.0), (-37.0, -34.0), (37.0, -34.0)]
RB_R = 3.8                             # rim boss O7.6
INS_R, INS_D = 2.0, 4.6                # M3x4 heat-set pocket (same as the cap's bracket inserts)
SCREW_R, CB_R, CB_D = 1.7, 3.3, 2.0    # deck: O3.4 clearance, O6.6 x 2.0 counterbore for an M3 button head (1.65)
# bezel hooks: (a, b of the core point, outward normal)
HOOKS = [((-L_ST, 0.0), (0, 1)), ((0.0, 0.0), (0, 1)), ((L_ST, 0.0), (0, 1)),
         ((-37.0, 0.0), (0, -1)), ((37.0, 0.0), (0, -1)),
         ((-L_ST, 0.0), (-1, 0)), ((L_ST, 0.0), (1, 0))]
BZ_T, BZ_OFF, BZ_SKIRT = 1.5, 1.6, 4.0


def pod_frame(X, Y, Z, O=None):
    O = O_MID if O is None else O
    qx, qy, qz = X - O[0], Y - O[1], Z - O[2]
    a = qx * F.U[0] + qy * F.U[1] + qz * F.U[2]
    b = qx * F.W[0] + qy * F.W[1] + qz * F.W[2]
    c = -(qx * F.D[0] + qy * F.D[1] + qz * F.D[2])
    return a, b, c


def stad(a, b, grow=0.0):
    return np.sqrt(np.maximum(np.abs(a) - L_ST, 0) ** 2 + b ** 2) - (R_ST + grow)


def swept(a, b, c):
    """(a', b'): the point moved along +Z onto the plate's rear plane (c = HEAD_Z1) when it lies behind it, so the
    shroud is the plate outline swept straight back along world Z; in front of that plane the sides run along the axis."""
    t = np.maximum(c - p.HEAD_Z1, 0) / ZD
    return a + t * ZU, b + t * ZW


def local(X, Y, Z, i):
    return pod_frame(X, Y, Z, CENTRES[i])


def env(x, y, z):
    head = p.cyl(x, y, z, p.HEAD_R, 0.0, p.HEAD_Z1)
    tube = p.cyl(x, y, z, p.BODY_R, p.HEAD_Z1 - 0.01, p.CAP_Z1)
    return np.minimum(head, tube)


LBOX = (-p.HEAD_R - 1.5, p.HEAD_R + 1.5, -p.HEAD_R - 1.5, p.HEAD_R + 1.5, -1.5, p.CAP_Z1 + 1.5)


def gauge_terms(X, Y, Z):
    """min over gauges of env, and of the cavities (env minus pod10 body). Evaluated only near each gauge."""
    E = np.full(X.shape, 1e3, np.float32); C = np.full(X.shape, 1e3, np.float32)
    for i in range(3):
        x, y, z = local(X, Y, Z, i)
        m = (x > LBOX[0]) & (x < LBOX[1]) & (y > LBOX[2]) & (y < LBOX[3]) & (z > LBOX[4]) & (z < LBOX[5])
        if not m.any():
            continue
        xm, ym, zm = x[m], y[m], z[m]
        e = env(xm, ym, zm)
        body = p.sdf_body(xm, ym, zm)
        E[m] = np.minimum(E[m], e)
        C[m] = np.minimum(C[m], np.maximum(e, -body))
    return E, C


def hook_frame(a, b, core, n):
    """radial / tangential coordinates for a hook on the stadium edge"""
    (ca, cb), (nx, ny) = core, n
    rad = (a - ca) * nx + (b - cb) * ny
    tan = -(a - ca) * ny + (b - cb) * nx
    return rad, tan


def boss_xy():
    out = []
    for a0, b0 in BOSS_AB:
        P = F.to_world(a0, b0, p.HEAD_Z1, O_MID)
        out.append((float(P[0]), float(P[1])))
    return out


BOSS_XY = boss_xy()


def sdf_pod(X, Y, Z):
    a, b, c = pod_frame(X, Y, Z)
    a2, b2 = swept(a, b, c)
    st = stad(a2, b2)
    solid = np.maximum.reduce([st, -c, RIM_Z - Z])
    void = np.maximum(st + WALL, SKIN - c)
    s = np.maximum(solid, -void)
    E, C = gauge_terms(X, Y, Z)
    s = np.minimum(s, E)
    for bx, by in BOSS_XY:                                         # rim boss columns along world Z
        col = np.maximum.reduce([np.sqrt((X - bx) ** 2 + (Y - by) ** 2) - RB_R, RIM_Z - Z, -c])
        s = np.minimum(s, np.maximum(col, st))                     # never outside the shroud
    s = np.maximum(s, -C)                                          # all head / tube cavities
    for bx, by in BOSS_XY:                                         # M3x4 insert pockets from the rim face + lead-in
        rr = np.sqrt((X - bx) ** 2 + (Y - by) ** 2)
        s = np.maximum(s, -np.maximum(rr - INS_R, np.maximum(RIM_Z - 1 - Z, Z - (RIM_Z + INS_D))))
        lead = rr - (INS_R + 0.4 - (Z - RIM_Z))
        s = np.maximum(s, -np.maximum(lead, np.maximum(RIM_Z - 1 - Z, Z - (RIM_Z + 0.4))))
    for core, n in HOOKS:                                          # bezel hook pockets in the plate edge (blind)
        rad, tan = hook_frame(a, b, core, n)
        pk = np.maximum.reduce([R_ST - 1.0 - rad, rad - (R_ST + 2.0), np.abs(tan) - 3.5, 1.2 - c, c - 3.2])
        s = np.maximum(s, -pk)
    return s


def sdf_bezel(X, Y, Z):
    a, b, c = pod_frame(X, Y, Z)
    st = stad(a, b)
    plate = np.maximum.reduce([st - BZ_OFF, -BZ_T - c, c])
    skirt = np.maximum.reduce([st - BZ_OFF, -(st - 0.2), -0.1 - c, c - BZ_SKIRT])
    s = np.minimum(plate, skirt)
    for O in CENTRES:
        x, y, z = pod_frame(X, Y, Z, O)
        r = np.sqrt(x ** 2 + y ** 2)
        s = np.maximum(s, -np.maximum(r - p.BEZEL_WIN_R, np.abs(z) - 4))                  # window
        cone = r - (p.BEZEL_WIN_R + 0.6 + (-BZ_T - z) * 1.0)                                # front chamfer
        s = np.maximum(s, -np.maximum(cone, np.maximum(-3 - z, z + 0.9)))
        bead = np.maximum.reduce([r - (p.LENS_R - 0.35), (p.BEZEL_WIN_R + 0.3) - r, -0.1 - z, z - p.BEAD_H])
        s = np.minimum(s, bead)
    for core, n in HOOKS:
        rad, tan = hook_frame(a, b, core, n)
        s = np.minimum(s, np.maximum.reduce([R_ST - 0.7 - rad, rad - (R_ST + 0.3), np.abs(tan) - 3.0, 1.5 - c, c - 2.9]))
        for sy in (-5.0, 5.0):                                                              # flex slits either side
            s = np.maximum(s, -np.maximum.reduce([R_ST - 1 - rad, rad - (R_ST + BZ_OFF + 1), np.abs(tan - sy) - 0.6,
                                                   0.4 - c, c - (BZ_SKIRT + 1)]))
    return s


# ---- base: deck + DIN box ------------------------------------------------------------------------------------------
BOX_WALL = 3.0
BOX_O = F.BOX_O
BOX_I = (BOX_O[0] + BOX_WALL, BOX_O[1] - BOX_WALL, BOX_O[2] + BOX_WALL, BOX_O[3] - BOX_WALL)


def rect2(X, Y, r):
    return np.maximum.reduce([r[0] - X, X - r[1], r[2] - Y, Y - r[3]])


def deck_clear_pts():
    """world points of each gauge's rear (tube / cap + 1 mm, plug zone + wire room) that come below RIM_Z + 1:
    the deck is opened under them."""
    pts = []
    th = np.linspace(0, 2 * np.pi, 720)
    for O in CENTRES:
        for z in np.linspace(p.HEAD_Z1, p.CAP_Z1 + WIRE, 40):
            for r in np.linspace(0, p.BODY_R + 1.0, 30):
                P = F.to_world(r * np.cos(th), r * np.sin(th), np.full_like(th, z), O)
                pts.append(P[P[:, 2] < RIM_Z + 1.0])
    return np.concatenate(pts)


_OPEN = {}
def open_field(res=None):
    """2D signed distance (world XY) of the deck opening under the gauges, on a fixed grid; cached."""
    res = res or RES
    if res in _OPEN:
        return _OPEN[res]
    from scipy import ndimage
    lo, hi = extents()
    xs = axes(lo[0] - 3, hi[0] + 3, res); ys = axes(lo[1] - 3, hi[1] + 3, res)
    pts = deck_clear_pts()
    m = np.zeros((len(xs), len(ys)), bool)
    ix = np.clip(np.round((pts[:, 0] - xs[0]) / res).astype(int), 0, len(xs) - 1)
    iy = np.clip(np.round((pts[:, 1] - ys[0]) / res).astype(int), 0, len(ys) - 1)
    m[ix, iy] = True
    m = ndimage.binary_closing(m, iterations=3)
    f = (ndimage.distance_transform_edt(~m) - ndimage.distance_transform_edt(m)) * res - 1.0   # 1 mm extra all round
    _OPEN[res] = (xs[0], ys[0], res, f.astype(np.float32))
    return _OPEN[res]


def open2d_at(X, Y):
    x0, y0, res, f = open_field()
    ix = np.clip(np.round((X - x0) / res).astype(int), 0, f.shape[0] - 1)
    iy = np.clip(np.round((Y - y0) / res).astype(int), 0, f.shape[1] - 1)
    return f[ix, iy]


# cable notch in the right-hand box wall under the right gauge's plugs (J_BUS1 / J_BUS2 / J_OUT sit over the wall)
def _notch():
    import cap4
    ys = []
    for (x0, x1, y0, y1) in cap4.WINDOWS.values():
        X, Y = np.meshgrid([x0, x1], [y0, y1])
        P = F.to_world(X.ravel(), Y.ravel(), np.full(4, p.CAP_Z1), CENTRES[2])
        ys += list(P[:, 1])
    return (F.BOX_O[1] - BOX_WALL - 1.0, F.BOX_O[1] + 1.0, min(ys) - 2.0, max(ys) + 2.0, 22.0)
NOTCH = _notch()                                                               # x0, x1, y0, y1, z floor


def sdf_base(X, Y, Z, open2d=None):
    open2d = open2d_at(X, Y) if open2d is None else open2d
    a, b, c = pod_frame(X, Y, Z)
    a2, b2 = swept(a, b, c)
    foot = stad(a2, b2)
    deck = np.maximum.reduce([foot, DECK_Z0 - Z, Z - RIM_Z])
    box = np.maximum.reduce([rect2(X, Y, BOX_O), F.BOX_Z0 - Z, Z - (DECK_Z0 + 0.5)])
    s = np.minimum(deck, box)
    s = np.maximum(s, -rect2(X, Y, BOX_I))                         # box bore, straight through the deck
    s = np.maximum(s, -np.maximum(open2d, DECK_Z0 - 0.01 - Z))     # clearance under the gauges (deck only)
    s = np.maximum(s, -np.maximum(rect2(X, Y, NOTCH[:4]), NOTCH[4] - Z))
    for bx, by in BOSS_XY:
        rr = np.sqrt((X - bx) ** 2 + (Y - by) ** 2)
        s = np.maximum(s, -(rr - SCREW_R))
        s = np.maximum(s, -np.maximum(rr - CB_R, Z - (DECK_Z0 + CB_D)))
    return s


# ---- meshing -------------------------------------------------------------------------------------------------------
def axes(lo, hi, res):
    o = 0.0137
    return np.arange(lo - o, hi + res, res, dtype=np.float64)


def march_slabs(fn, xs, ys, zs, slab=60, **kw):
    V, Fc, nv = [], [], 0
    i = 0
    while i < len(xs) - 1:
        j = min(i + slab, len(xs) - 1)
        X, Y, Z = np.meshgrid(xs[i:j + 1], ys, zs, indexing='ij')
        s = fn(X, Y, Z, **kw).astype(np.float32)
        if s.min() < 0 < s.max():
            v, f, _, _ = measure.marching_cubes(s, level=0.0, spacing=(xs[1] - xs[0],) * 3)
            v = v + np.array([xs[i], ys[0], zs[0]])
            V.append(v); Fc.append(f + nv); nv += len(v)
        i = j
        print('  slab x %.1f' % xs[j], flush=True)
    V = np.concatenate(V); Fc = np.concatenate(Fc)
    q = np.round(V / 1e-4).astype(np.int64)                         # weld the slab seams
    _, idx, inv = np.unique(q, axis=0, return_index=True, return_inverse=True)
    V = V[idx]; Fc = inv.reshape(-1)[Fc]
    keep = (Fc[:, 0] != Fc[:, 1]) & (Fc[:, 1] != Fc[:, 2]) & (Fc[:, 0] != Fc[:, 2])
    return V, Fc[keep]


def write_stl(path, V, Fc, name=b'can2gauge_tri'):
    tri = V[Fc].astype(np.float32)
    vol = np.einsum('ij,ij->i', tri[:, 0], np.cross(tri[:, 1], tri[:, 2])).sum() / 6
    if vol < 0:                                                     # outward normals for slicers
        tri = tri[:, ::-1]; vol = -vol
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0]); n /= np.linalg.norm(n, axis=1, keepdims=True) + 1e-12
    data = np.zeros(len(tri), dtype=np.dtype([('n', '<f4', 3), ('v', '<f4', (3, 3)), ('a', '<u2')]))
    data['n'] = n; data['v'] = tri
    with open(path, 'wb') as fh:
        fh.write(name.ljust(80, b'\0')); fh.write(np.uint32(len(tri)).tobytes()); fh.write(data.tobytes())
    return vol


def edge_check(Fc):
    e = np.sort(np.concatenate([Fc[:, [0, 1]], Fc[:, [1, 2]], Fc[:, [2, 0]]]), axis=1)
    _, cnt = np.unique(e, axis=0, return_counts=True)
    return int((cnt != 2).sum())


def extents():
    a = np.linspace(-L_ST - R_ST - BZ_OFF, L_ST + R_ST + BZ_OFF, 200); b = np.linspace(-R_ST - BZ_OFF, R_ST + BZ_OFF, 60)
    A, B = np.meshgrid(a, b)
    pts = [F.to_world(A.ravel(), B.ravel(), np.full(A.size, z), O_MID) for z in (-BZ_T, p.HEAD_Z1)]
    P = np.concatenate(pts)
    return P.min(0), P.max(0)


if __name__ == '__main__':
    out = sys.argv[1] if len(sys.argv) > 1 else 'out'
    parts = sys.argv[2].split(',') if len(sys.argv) > 2 else ['pod', 'bezel', 'base']
    os.makedirs(out, exist_ok=True)
    lo, hi = extents()
    print('pod extents', lo.round(1), hi.round(1))
    # shroud footprint on the rim plane (along Z) for the x / y range
    xr = (lo[0] - 3, hi[0] + 3); yr = (lo[1] - 3, hi[1] + 3)
    if 'pod' in parts:
        xs, ys, zs = axes(*xr, RES), axes(*yr, RES), axes(RIM_Z - 5, hi[2] + 3, RES)
        V, Fc = march_slabs(sdf_pod, xs, ys, zs)
        vol = write_stl(os.path.join(out, 'can2gauge_tri_pod_V1-0.stl'), V, Fc)
        print('pod', len(Fc), 'faces, %.1f cm3, open edges %d' % (vol / 1e3, edge_check(Fc)))
    if 'bezel' in parts:
        r = min(RES, 0.15)                                          # fine grid for the 0.1 bead
        A_ = axes(-L_ST - R_ST - BZ_OFF - 1, L_ST + R_ST + BZ_OFF + 1, r); B_ = axes(-R_ST - BZ_OFF - 1, R_ST + BZ_OFF + 1, r)
        C_ = axes(-BZ_T - 0.6, BZ_SKIRT + 0.6, r)
        def fnb(A, B, C):                                           # meshed in the pod frame, then moved into place
            P = O_MID + A[..., None] * F.U + B[..., None] * F.W - C[..., None] * F.D
            return sdf_bezel(P[..., 0], P[..., 1], P[..., 2])
        V, Fc = march_slabs(fnb, A_, B_, C_, slab=80)
        V = F.to_world(V[:, 0], V[:, 1], V[:, 2], O_MID)
        vol = write_stl(os.path.join(out, 'can2gauge_tri_bezel_V1-0.stl'), V, Fc)
        print('bezel', len(Fc), 'faces, %.1f cm3, open edges %d' % (vol / 1e3, edge_check(Fc)))
    if 'base' in parts:
        xs, ys, zs = axes(*xr, RES), axes(*yr, RES), axes(F.BOX_Z0 - 2, RIM_Z + 2, RES)
        fn = sdf_base
        V, Fc = march_slabs(fn, xs, ys, zs)
        vol = write_stl(os.path.join(out, 'can2gauge_tri_base_V1-0.stl'), V, Fc)
        print('base', len(Fc), 'faces, %.1f cm3, open edges %d' % (vol / 1e3, edge_check(Fc)))
