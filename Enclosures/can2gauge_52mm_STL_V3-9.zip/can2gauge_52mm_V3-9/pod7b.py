"""can2gauge housing V3.9 (V3.5 base) - standard 52 mm DIN gauge body for the Saef SF-TC210B-8947A3N 2.1" panel and the rev15 board.
Parametric SDF model (numpy + scikit-image).

Frame: x, y = the scripts' model frame M = board / panel seen from the FRONT (x right, y up = antenna end), z = depth
backwards from the glass front (z = 0). EasyEDA's own top view is M flipped vertically; write_stl() mirrors x so every
STL is the real (right-handed) part - the rear view then shows the plugs on the left and the USB-C on the right.

  bezel ring   -1.5 .. 0        snap-on, window O53.6, lip over the glass edge (glass goes in from the front)
  LCM           0 .. 2.26       O58.18 + neck (60.71 tall), FPC leaves the neck end ~0.8 mm behind the front
  head          0 .. HEAD_Z1    flange on the dash: glass + neck pocket, flex cavity (fold, run, +z drop), 3 PCB bosses
  front parts   Z_PCB_F-3 .. Z_PCB_F   everything on the glass side <= 3.0 mm (0.5 mm air to the worst-case LCM back)
  PCB           Z_PCB_F .. Z_PCB_B     module + FPC connector + plugs on the REAR face
  flex          neck end -> 180 deg fold in the drawing's bending area -> +y run behind the neck -> 90 deg to +z 3 mm
                outside the PCB flat (so the 5.0+-0.5 mm stiffener stays straight) -> 90 deg -> J_LCD. That +z run is outside
                the 52 mm hole, which is what sets the head depth (dash face) at HEAD_Z1.
  body tube     HEAD_Z1 .. CAP_Z1   O51.8 / O48.8 through the 52 mm hole
  rear cap      floor CAP_Z0..CAP_Z1: plug windows, USB-C slot, BOOT/RESET holes, LED window, 3 posts, 2 bracket bosses
                V3.7: the bracket bosses are INSIDE the cap (back face dead flat, prints back-face-down with no supports);
                M3x4 inserts go in from the back face, the bracket bar sits flat on the cap.
Retention: 3x M2x12 cap screws from the back into M2x3 heat-set inserts in the head bosses; U-bracket on two M3 studs.
"""
import numpy as np, struct, os, sys, math
from skimage import measure
import geom

RES = float(os.environ.get("ENC_RES", "0.25"))

# ---- frame: every coordinate below is in the scripts' model frame M = the board / panel seen from the FRONT (x right,
#      y up = antenna, z backwards from the glass front). The EasyEDA file's own top view is M flipped vertically, so the
#      real rear view is M mirrored in x: write_stl() mirrors x so the printed parts are the right hand.
# ---- LCD: Saef SF-TC210B-8947A3N drawing (rev A, 2023-08-02)
GLASS_R = 58.18 / 2            # LCM OD 58.18 +-0.2 (metal frame; TFT 55.88, POL 55.38, AA 53.28)
LCM_TOL = 0.2
NECK_HW = 33.6 / 2             # neck (TFT ledge) outer walls, measured off the drawing
NECK_Y = GLASS_R - 60.71       # neck end, -31.62 (LCM height 60.71 +-0.2)
LCM_T = 2.26                   # 2.26 +-0.2
FLEX_Z0 = 0.8                  # the FPC leaves the TFT ledge ~0.8 mm behind the glass front (side view)
FLEX_T = 0.3
FLEX_W = 20.5                  # tail width (19.5 contact pitch field + 0.5 each side)
FPC_WIDE = (-14.1, 14.6)       # first ~14 mm below the neck: 28.7 mm wide (x seen from the front)
FPC_BUMP_X0 = -15.6            # 'protect tape' circuit bump on the left, 5 .. 13 mm below the neck
FPC_WIDE_L = 14.0              # wide -> 20.5 mm step, from the neck end
FPC_BEND = (0.5, 4.9)          # drawing's BENDING AREA, from the neck end
FPC_LEN = 26.59                # neck end -> tail end (+-0.3)
FPC_CONTACT = 3.5              # exposed contacts = insertion depth
STIFF_L = 5.0 + 0.5            # PI stiffener 5.00 +-0.5 -> worst case 5.5 must stay straight
# ---- stack
PCB_T = 1.6
Z_GLASS_B = LCM_T + LCM_TOL    # worst-case glass back face
Z_POCKET = Z_GLASS_B           # glass pocket floor
FRONT_H = 3.0                  # tallest glass-side part (RS0530 / FNR4030 / SMA)
Z_PCB_F = round(Z_POCKET + 0.5 + FRONT_H, 1)      # 6.0
Z_PCB_B = Z_PCB_F + PCB_T      # 7.6
FOLD_R = 1.1                   # 180 deg fold inside the bending area (arc 3.5 mm starting 0.5 mm below the neck)
BEND_R = 1.0                   # the two 90 deg bends
FLEX_ENTRY_Z = Z_PCB_B + 1.1   # FPC slot height of the XUNPU FPC-05FB-40PH20 (H2.0)
JLCD_FACE_Y = geom.FLAT_Y + 0.08   # connector front face (flush with the flat)
FLEX_INSERT = FPC_CONTACT
FLEX_Z_RUN = FLEX_Z0 + 2 * FOLD_R  # +y run behind the neck, 3.0
FLEX_DROP_Y = JLCD_FACE_Y + FLEX_INSERT - STIFF_L - 0.2 - BEND_R   # +z run centre line, -23.87: stiffener kept straight
CAV_TOP = FLEX_ENTRY_Z + FLEX_T / 2 + 0.3
HEAD_Z1 = round(CAV_TOP + 0.65, 1)                 # head rear face = dash contact: the flex's +z run sits outside the
                                                   # 52 mm hole (r 26.1 at its corners), so it must stay inside the head
FLEX_Y_MIN = NECK_Y - FPC_BEND[0] - FOLD_R - FLEX_T / 2
HEAD_R = math.ceil((math.hypot(max(-FPC_WIDE[0], FPC_WIDE[1]) + 0.4, FLEX_Y_MIN - 0.4) + 1.2) * 10) / 10   # fold corners + 1.2 wall
BODY_R = 25.9                  # O51.8 through a 52 mm hole
BODY_IR = 24.4                 # O48.8 bore, PCB is O48
CAP_Z0 = Z_PCB_B + 8.7         # cap floor inner face (USB-C 10.0 pokes 1.3 into its slot)
CAP_T = 3.0
CAP_Z1 = CAP_Z0 + CAP_T
CAP_R = BODY_IR - 0.25
SKIRT_Z0 = CAP_Z0 - 3.8
PCB_R = geom.R
NOTCH_X0, NOTCH_X1, NOTCH_D, FLAT_Y = geom.NOTCH_X0, geom.NOTCH_X1, geom.NOTCH_D, geom.FLAT_Y
HOLES = geom.HOLES
BOSS_R = 3.6                   # V3.6: O7.2 (was O5.0 -> 0.95 mm wall round an M2 insert), fused to the bore wall
POST_R = 2.2
SCREW_CLR_R = 1.2
CB_R = 2.1
SCREW_L = 12.0
INSERT_R = 1.6                 # M2 x 3 heat-set insert (OD <= 3.6), O3.2 hole
INSERT_L = 3.0
POCKET_R = 1.6                 # O3.2 x 3.0 insert pocket from the PCB face, O3.8 lead-in
POCKET_D = 3.0
RELIEF_R = 1.25                # O2.5 screw-tip relief below the pocket (no floor fits: the glass is 0.3 mm in front)
SCREW_HEAD_Z = CAP_Z0
SCREW_TIP_Z = SCREW_HEAD_Z - SCREW_L
BOSS_Z0 = Z_POCKET + 0.3
# ---- bezel
BEZEL_T = 1.5
BEZEL_WIN_R = 53.6 / 2
BEZEL_R = HEAD_R + 1.6
SKIRT_L = 4.0
SNAP_ANGLES = (30, 150, 210, 330)
# ---- cap openings (V3.3: generated from the placement by gen_cap33.py -> cap33.py)
import cap4 as cap33
USB_POSE = cap33.USB_POSE
BUTTON_XY = cap33.BUTTON_XY
LED_XY = cap33.LED_XY
# ---- V3.8 (28 Oct 2026): neck pocket and flex cavity opened out after the first fit
NECK_CLR = 0.4                 # neck pocket clearance per side beyond LCM_TOL (was 0.2)
NECK_FILLET = 3.0              # round the wall where the neck box meets the round pocket (was a sharp point that
                               # pressed the glass's own neck fillet)
FPC_CAV_X = (-16.4, 16.5)      # flex cavity width: SFTO210XC drawing has the wide part (IC + 7-pin touch pads) out to
                               # x +15.3, the old model had 14.6 + 0.4. Now ~1.2 mm each side for the touch tail + solder
FPC_CAV_ZTOP = 8.0             # fold / run headroom towards the back (was 4.9 / 6.4); 1.8 mm left to the dash face
FPC_CAV_YEXT = 0.8             # fold zone runs 0.8 further out (was 0.4)
FPC_CAV_RMAX = None            # set below: cavity clipped to HEAD_R - 1.2 so the head stays the same size
STUD_XY = ((-2.0, 12.0), (-2.0, -12.0))      # M3 inserts for the bracket (24 mm spacing, clear of the windows)
CONN_WINDOWS = cap33.WINDOWS                 # ref -> (x0, x1, y0, y1): connector body + latch / finger margin
STUD_R, STUD_HOLE_R = 3.6, 2.0               # V3.7: internal boss O7.2, O4.0 pocket for an M3x4 heat-set insert
STUD_H = 0.0                                 # nothing on the back face any more
INS3_D = 4.6                                 # pocket depth from the back face (insert 4.0 + 0.6 for displaced plastic)
BOSS3_FLOOR = 0.8                            # blind end of the pocket
BOSS3_Z0 = CAP_Z1 - INS3_D - BOSS3_FLOOR     # boss face inside the cap (13.9: 3.2 mm over the module, 4.3 over J_LCD)
def flex_path():
    """(y, z) polyline of the flex centre line from the neck end: 0.5 straight, 180 deg fold (bending area) back under the
    neck, +y run behind the neck, 90 deg to +z 1.2 mm beyond the stiffener, +z past the PCB edge, 90 deg to +y, the straight
    stiffened 5.5 mm into J_LCD on the rear face."""
    pts = [(NECK_Y + 1.0, FLEX_Z0), (NECK_Y, FLEX_Z0)]
    y0 = NECK_Y - FPC_BEND[0]
    pts.append((y0, FLEX_Z0))
    for a in np.linspace(0, np.pi, 17)[1:]:
        pts.append((y0 - FOLD_R * np.sin(a), FLEX_Z0 + FOLD_R - FOLD_R * np.cos(a)))
    yv = FLEX_DROP_Y - BEND_R
    pts.append((yv, FLEX_Z_RUN))
    for a in np.linspace(0, np.pi / 2, 9)[1:]:
        pts.append((yv + BEND_R * np.sin(a), FLEX_Z_RUN + BEND_R - BEND_R * np.cos(a)))
    z2 = FLEX_ENTRY_Z - BEND_R
    pts.append((FLEX_DROP_Y, z2))
    for a in np.linspace(0, np.pi / 2, 9)[1:]:
        pts.append((FLEX_DROP_Y + BEND_R - BEND_R * np.cos(a), z2 + BEND_R * np.sin(a)))
    pts.append((JLCD_FACE_Y + FLEX_INSERT, FLEX_ENTRY_Z))
    return pts


def flex_length():
    p = flex_path()
    return sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(p[1:], p[2:]))


def flex_width_at(s):
    """FPC x extents at arc length s from the neck end (front-view x = model x)"""
    if s < FPC_WIDE_L:
        x0 = FPC_BUMP_X0 if 5.0 <= s <= 13.0 else FPC_WIDE[0]
        return x0, FPC_WIDE[1]
    return -FLEX_W / 2, FLEX_W / 2


def grid(xr, yr, zr, res=None):
    res = res or RES
    o = 0.0137                     # grid kept off the round-number planes (no zero-valued nodes -> clean manifold mesh)
    xs = np.arange(xr[0] - o, xr[1] + res, res, dtype=np.float32)
    ys = np.arange(yr[0] - o, yr[1] + res, res, dtype=np.float32)
    zs = np.arange(zr[0] - o, zr[1] + res, res, dtype=np.float32)
    X, Y, Z = np.meshgrid(xs, ys, zs, indexing='ij')
    return xs, ys, zs, X, Y, Z


def cyl(X, Y, Z, r, z0, z1, cx=0.0, cy=0.0):
    return np.maximum(np.sqrt((X - cx) ** 2 + (Y - cy) ** 2) - r, np.maximum(z0 - Z, Z - z1))


def box(X, Y, Z, x0, x1, y0, y1, z0, z1):
    return np.maximum.reduce([x0 - X, X - x1, y0 - Y, Y - y1, z0 - Z, Z - z1])


def rrect(X, Y, Z, cx, cy, w, h, r, z0, z1):
    qx = np.abs(X - cx) - (w / 2 - r); qy = np.abs(Y - cy) - (h / 2 - r)
    d2 = np.sqrt(np.maximum(qx, 0) ** 2 + np.maximum(qy, 0) ** 2) + np.minimum(np.maximum(qx, qy), 0) - r
    return np.maximum(d2, np.maximum(z0 - Z, Z - z1))


def rrect_rot(X, Y, Z, cx, cy, w, h, r, z0, z1, ang):
    a = np.radians(ang); ca, sa = np.cos(a), np.sin(a)
    Xr = ca * (X - cx) + sa * (Y - cy); Yr = -sa * (X - cx) + ca * (Y - cy)
    return rrect(Xr, Yr, Z, 0.0, 0.0, w, h, r, z0, z1)


U = np.minimum
I = np.maximum
def D(a, b): return np.maximum(a, -b)


def pcb_outline2d(X, Y):
    base = np.maximum(np.sqrt(X ** 2 + Y ** 2) - PCB_R, FLAT_Y - Y)
    nx0, nx1, ny = geom.NOTCH                                           # V3.3: the user's antenna notch
    notch = np.maximum.reduce([nx0 - X, X - nx1, ny - Y])
    return np.maximum(base, -notch)


# ---------------------------------------------------------------------------
def sdf_flex_cavity(X, Y, Z):
    """room for the FPC in the head: fold zone beyond the neck end (28.7 wide), the +y run behind the neck with the
    'protect tape' bump and 1.9 mm headroom for the slack to bow, the +z run past the PCB flat and the bend into J_LCD
    (20.5 wide, which is what passes the flat edge)."""
    x0, x1 = FPC_CAV_X                                                   # V3.8: wider and deeper (touch tail + solder)
    ylo = FLEX_Y_MIN - FPC_CAV_YEXT
    fold = box(X, Y, Z, x0, x1, ylo, NECK_Y + 0.5, -1.0, FPC_CAV_ZTOP)
    run = box(X, Y, Z, x0, x1, ylo, FLEX_DROP_Y + 1.2, Z_POCKET - 0.01, FPC_CAV_ZTOP)
    clip = np.sqrt(X ** 2 + Y ** 2) - (HEAD_R - 1.2)                     # keep 1.2 mm of head wall: head size unchanged
    fr = I(U(fold, run), clip)
    zrun = box(X, Y, Z, -FLEX_W / 2 - 0.5, FLEX_W / 2 + 0.5, FLEX_DROP_Y - 1.4, FLAT_Y - 0.6, Z_POCKET - 0.01, CAV_TOP)
    # V3.9 / CT V4.2: the run's +y end used to stop at FLEX_DROP_Y + 1.2, leaving a ledge between it and the bore at
    # both sides of the +z drop; the wide part of the ribbon (IC + touch pads) bowed into those two edges. Opened
    # straight into the bore over the full cavity width (the PCB bosses are re-added after this cut, so they stay whole).
    ext = box(X, Y, Z, x0, x1, FLEX_DROP_Y + 0.5, -10.0, Z_POCKET - 0.03, FPC_CAV_ZTOP)   # (inside the bore it's void anyway)
    return np.minimum.reduce([fr, zrun, ext])


def sdf_body(X, Y, Z):
    """head flange + body tube + PCB bosses (one print)."""
    head = cyl(X, Y, Z, HEAD_R, 0.0, HEAD_Z1)
    tube = D(cyl(X, Y, Z, BODY_R, HEAD_Z1 - 0.01, CAP_Z1), cyl(X, Y, Z, BODY_IR, HEAD_Z1 - 1, CAP_Z1 + 1))
    s = U(head, tube)
    # glass pocket (LCM OD + tolerance + 0.15) + neck pocket, open at the front; bore behind the glass
    gr = GLASS_R + LCM_TOL + 0.15
    # V3.8: round pocket + neck pocket joined with a 2D smooth union, so the wall where they meet is a radius, not a
    # sharp point (it pressed into the glass's neck fillet); the neck itself gets 0.4 mm a side (was 0.2)
    c2 = np.sqrt(X ** 2 + Y ** 2) - gr
    hw = NECK_HW + LCM_TOL + NECK_CLR; ny0 = NECK_Y - LCM_TOL - NECK_CLR
    qx = np.abs(X) - hw; qy = np.abs(Y - (ny0 - 18.0) / 2) - (-18.0 - ny0) / 2
    b2 = np.sqrt(np.maximum(qx, 0) ** 2 + np.maximum(qy, 0) ** 2) + np.minimum(np.maximum(qx, qy), 0)
    k = NECK_FILLET; hk = np.clip(0.5 + 0.5 * (b2 - c2) / k, 0, 1)
    pk2 = b2 * (1 - hk) + c2 * hk - k * hk * (1 - hk)                  # polynomial smooth-min, 2D only (floor stays flat)
    s = D(s, I(pk2, np.maximum(-1.0 - Z, Z - Z_POCKET)))
    s = D(s, cyl(X, Y, Z, BODY_IR, Z_POCKET - 0.01, CAP_Z1 + 1))
    s = D(s, sdf_flex_cavity(X, Y, Z))
    # PCB bosses (V3.6): O7.2, fused to the bore wall over their full width and height, M2 insert pocket + tip relief
    for hx, hy in HOLES:
        ang = math.degrees(math.atan2(hy, hx)); rr = math.hypot(hx, hy)
        boss = cyl(X, Y, Z, BOSS_R, BOSS_Z0, Z_PCB_F, hx, hy)
        L = BODY_IR + 1.0 - rr                                         # boss centre -> 1 mm into the wall
        cx, cy = (rr + L / 2) * math.cos(math.radians(ang)), (rr + L / 2) * math.sin(math.radians(ang))
        web = rrect_rot(X, Y, Z, cx, cy, L, 2 * BOSS_R, 0.4, BOSS_Z0, Z_PCB_F, ang)
        s = U(s, I(U(boss, web), cyl(X, Y, Z, BODY_R - 0.01, -1, 40)))
    for hx, hy in HOLES:
        s = D(s, cyl(X, Y, Z, POCKET_R, Z_PCB_F - POCKET_D, Z_PCB_F + 1, hx, hy))
        s = D(s, cyl(X, Y, Z, RELIEF_R, BOSS_Z0 - 1, Z_PCB_F - POCKET_D + 0.01, hx, hy))
        lead = np.sqrt((X - hx) ** 2 + (Y - hy) ** 2) - (POCKET_R + 0.3 - (Z_PCB_F - Z))     # 0.3 x 45 deg lead-in
        s = D(s, I(lead, np.maximum(Z_PCB_F - 0.3 - Z, Z - Z_PCB_F - 0.01)))
    # bezel snap pockets in the head's outer wall (blind)
    for ang in SNAP_ANGLES:
        a = np.radians(ang)
        Xr = X * np.cos(a) + Y * np.sin(a); Yr = -X * np.sin(a) + Y * np.cos(a)
        s = D(s, box(Xr, Yr, Z, HEAD_R - 1.0, HEAD_R + 2.0, -3.5, 3.5, 1.2, 3.2))
    return s


def sdf_bezel(X, Y, Z):
    plate = cyl(X, Y, Z, BEZEL_R, -BEZEL_T, 0.0)
    plate = D(plate, cyl(X, Y, Z, BEZEL_WIN_R, -4, 2))
    skirt = D(cyl(X, Y, Z, BEZEL_R, -0.1, SKIRT_L), cyl(X, Y, Z, HEAD_R + 0.2, -1, SKIRT_L + 1))
    s = U(plate, skirt)
    cone = np.sqrt(X ** 2 + Y ** 2) - (BEZEL_WIN_R + 0.6 + (-BEZEL_T - Z) * 1.0)
    s = D(s, I(cone, box(X, Y, Z, -40, 40, -40, 40, -3, -0.9)))
    for ang in SNAP_ANGLES:
        a = np.radians(ang)
        Xr = X * np.cos(a) + Y * np.sin(a); Yr = -X * np.sin(a) + Y * np.cos(a)
        s = U(s, box(Xr, Yr, Z, HEAD_R - 0.7, HEAD_R + 0.3, -3.0, 3.0, 1.5, 2.9))       # hook
        for sy in (-5.0, 5.0):
            s = D(s, box(Xr, Yr, Z, HEAD_R - 1, BEZEL_R + 1, sy - 0.6, sy + 0.6, 0.4, SKIRT_L + 1))   # flex slits
    return s


def sdf_cap(X, Y, Z):
    s = cyl(X, Y, Z, CAP_R, CAP_Z0, CAP_Z1)                                            # floor
    s = U(s, D(cyl(X, Y, Z, CAP_R, SKIRT_Z0, CAP_Z0 + 0.01), cyl(X, Y, Z, CAP_R - 1.5, SKIRT_Z0 - 1, CAP_Z0 - 0.01)))   # skirt
    for hx, hy in HOLES:                                                              # posts down to the PCB back face
        s = U(s, cyl(X, Y, Z, POST_R, Z_PCB_B, CAP_Z0 + 0.5, hx, hy))
        s = U(s, I(cyl(X, Y, Z, POST_R + 1.0, CAP_Z0 - 1.0, CAP_Z0 + 0.5, hx, hy),
                   (np.sqrt((X - hx) ** 2 + (Y - hy) ** 2) - (POST_R + 1.0 - (CAP_Z0 - Z)))))     # fillet cone
    for r, x0, x1, y0, y1 in getattr(cap33, 'POST_KEEPOUT', ()):                      # parts crowding a post (C18 ...)
        s = D(s, box(X, Y, Z, x0 - 0.25, x1 + 0.25, y0 - 0.25, y1 + 0.25, Z_PCB_B - 1, Z_PCB_B + 2.0))
    s = I(s, cyl(X, Y, Z, CAP_R, -1, CAP_Z1 + 0.01))                                    # posts near the rim are flattened to the bore
    for sx, sy in STUD_XY:                                                            # V3.7: bracket bosses inside the cap
        s = U(s, cyl(X, Y, Z, STUD_R, BOSS3_Z0, CAP_Z0 + 0.5, sx, sy))
        s = U(s, I(cyl(X, Y, Z, STUD_R + 0.8, CAP_Z0 - 0.8, CAP_Z0 + 0.5, sx, sy),
                   np.sqrt((X - sx) ** 2 + (Y - sy) ** 2) - (STUD_R + 0.8 - (CAP_Z0 - Z))))      # root fillet
    for hx, hy in HOLES:
        s = D(s, cyl(X, Y, Z, SCREW_CLR_R, Z_PCB_B - 1, CAP_Z1 + 1, hx, hy))
        s = D(s, cyl(X, Y, Z, CB_R, SCREW_HEAD_Z, CAP_Z1 + 1, hx, hy))
        # V3.7 bridging trick (cap prints back-face-down): the counterbore floor is a ceiling, so the first 0.4 mm above
        # it is a slot as wide as the screw hole across the whole counterbore and the next 0.4 mm a square - every layer
        # then bridges straight between solid edges instead of hanging a ring round a round hole.
        hw = SCREW_CLR_R
        s = D(s, box(X, Y, Z, hx - CB_R, hx + CB_R, hy - hw, hy + hw, SCREW_HEAD_Z - 0.4, SCREW_HEAD_Z + 0.01))
        s = D(s, box(X, Y, Z, hx - hw, hx + hw, hy - hw, hy + hw, SCREW_HEAD_Z - 0.8, SCREW_HEAD_Z + 0.01))
    for sx, sy in STUD_XY:                                                            # insert pocket from the back face
        s = D(s, cyl(X, Y, Z, STUD_HOLE_R, CAP_Z1 - INS3_D, CAP_Z1 + 1, sx, sy))
        lead = np.sqrt((X - sx) ** 2 + (Y - sy) ** 2) - (STUD_HOLE_R + 0.4 - (CAP_Z1 - Z))      # 0.4 x 45 deg lead-in
        s = D(s, I(lead, np.maximum(CAP_Z1 - 0.4 - Z, Z - CAP_Z1 - 1)))
    fz0, fz1 = CAP_Z0 - 1, CAP_Z1 + 1
    ux, uy, urot = USB_POSE
    s = D(s, rrect_rot(X, Y, Z, ux, uy, 13.0, 7.0, 1.5, fz0, fz1, urot))                # USB-C plug overmold
    for ref, (x0, x1, y0, y1) in CONN_WINDOWS.items():                                 # one window per plug
        s = D(s, rrect(X, Y, Z, (x0 + x1) / 2, (y0 + y1) / 2, x1 - x0, y1 - y0, 0.6, fz0, fz1))
    for bx, by in BUTTON_XY:                                                          # BOOT / RESET pin holes
        s = D(s, cyl(X, Y, Z, 1.0, fz0, fz1, bx, by))
    s = D(s, cyl(X, Y, Z, 1.3, fz0, fz1, LED_XY[0], LED_XY[1]))                      # power LED window
    return s


def sdf_bracket(X, Y, Z):
    """U-bracket: bar behind the cap on the two studs, legs bear on the dash outside the 52 mm hole. Modelled in place
    for a 3 mm panel (bar at z HEAD_Z1 + 3 + LEG_L); print flat."""
    zb = CAP_Z1 + STUD_H
    LEG_L = zb - (HEAD_Z1 + 3.0)
    bar = rrect(X, Y, Z, -2.0, 0, 12.0, 66.0, 2.0, zb, zb + 3.0)
    legs = U(box(X, Y, Z, -8, 4, 29.0, 33.0, zb - LEG_L, zb + 0.01), box(X, Y, Z, -8, 4, -33.0, -29.0, zb - LEG_L, zb + 0.01))
    s = U(bar, legs)
    for sx, sy in STUD_XY:
        s = D(s, rrect(X, Y, Z, sx, sy, 3.4, 8.0, 1.6, zb - 1, zb + 4))                # slots for the M3 screws
    return s


def sdf_pcb(X, Y, Z):
    s = I(pcb_outline2d(X, Y), np.maximum(Z_PCB_F - Z, Z - Z_PCB_B))
    for hx, hy in HOLES:
        s = D(s, cyl(X, Y, Z, 1.1, Z_PCB_F - 1, Z_PCB_B + 1, hx, hy))
    return s


def sdf_glass(X, Y, Z):
    c = np.sqrt(X ** 2 + Y ** 2) - GLASS_R
    neck = np.maximum.reduce([-NECK_HW - X, X - NECK_HW, NECK_Y - Y, Y + 20])
    return I(np.minimum(c, neck), np.maximum(0 - Z, Z - LCM_T))


# ---------------------------------------------------------------------------
def march(sdf_fn, xr, yr, zr, res=None):
    res = res or RES
    xs, ys, zs, X, Y, Z = grid(xr, yr, zr, res)
    s = sdf_fn(X, Y, Z)
    v, f, _, _ = measure.marching_cubes(s, level=0.0, spacing=(res, res, res))
    v = v + np.array([xs[0], ys[0], zs[0]], dtype=np.float32)
    return v.astype(np.float32), f[:, ::-1]


def write_stl(path, verts, faces, name=b'can2gauge', mirror=True):
    """mirror=True: model frame M (seen from the front) -> real right-handed part (x -> -x). march() hands out inward-wound
    faces; the mirror turns them outward, which is what slicers expect."""
    if mirror:
        verts = verts * np.array([-1.0, 1.0, 1.0], dtype=np.float32)
    tri = verts[faces]
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    n /= (np.linalg.norm(n, axis=1, keepdims=True) + 1e-12)
    with open(path, 'wb') as fh:
        fh.write(name.ljust(80, b'\0'))
        fh.write(struct.pack('<I', len(faces)))
        data = np.zeros(len(faces), dtype=np.dtype([('n', '<f4', 3), ('v', '<f4', (3, 3)), ('a', '<u2')]))
        data['n'] = n; data['v'] = tri
        fh.write(data.tobytes())


R = HEAD_R + 2
PARTS = {  # name: (sdf, x range, y range, z range)
    'body': (sdf_body, (-R, R), (-R, R), (-1, CAP_Z1 + 1)),
    'bezel': (sdf_bezel, (-BEZEL_R - 1, BEZEL_R + 1), (-BEZEL_R - 1, BEZEL_R + 1), (-BEZEL_T - 1, SKIRT_L + 1)),
    'cap': (sdf_cap, (-CAP_R - 1, CAP_R + 1), (-CAP_R - 1, CAP_R + 1), (Z_PCB_B - 1, CAP_Z1 + STUD_H + 1)),
    'bracket': (sdf_bracket, (-10, 6), (-35, 35), (HEAD_Z1 + 2, CAP_Z1 + STUD_H + 4)),
}

if __name__ == '__main__':
    out = sys.argv[1] if len(sys.argv) > 1 else '.'
    os.makedirs(out, exist_ok=True)
    for name, (fn, xr, yr, zr) in PARTS.items():
        v, f = march(fn, xr, yr, zr)
        write_stl(os.path.join(out, 'can2gauge_52mm_%s_V3-9.stl' % name), v, f)
        print(name, len(f), 'faces')
    print('stack: LCD 0..%.1f  pocket floor %.1f  PCB %.1f..%.1f  head rear %.1f  cap floor %.1f..%.1f  screw head %.1f tip %.1f' %
          (LCM_T, Z_POCKET, Z_PCB_F, Z_PCB_B, HEAD_Z1, CAP_Z0, CAP_Z1, SCREW_HEAD_Z, SCREW_TIP_Z))
    print('flex needed from the neck end: %.2f mm of %.2f (slack %.2f); fold reaches y %.2f; +z run at y %.2f; head O%.1f, dash face z %.2f' %
          (flex_length(), FPC_LEN, FPC_LEN - flex_length(), FLEX_Y_MIN, FLEX_DROP_Y, 2 * HEAD_R, HEAD_Z1))
